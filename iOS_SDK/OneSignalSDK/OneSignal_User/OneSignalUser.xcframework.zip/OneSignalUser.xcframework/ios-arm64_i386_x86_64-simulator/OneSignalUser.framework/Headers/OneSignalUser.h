//
//  OneSignalUser.h
//  OneSignalUser
//
//  Created by Elliot Mawby on 5/13/22.
//  Copyright © 2022 Hiptic. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for OneSignalUser.
FOUNDATION_EXPORT double OneSignalUserVersionNumber;

//! Project version string for OneSignalUser.
FOUNDATION_EXPORT const unsigned char OneSignalUserVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OneSignalUser/PublicHeader.h>

//#import <OneSignalUser/OneSignalUser-Swift.h>
