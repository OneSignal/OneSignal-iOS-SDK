/**
 * Modified MIT License
 *
 * Copyright 2021 OneSignal
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * 1. The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * 2. All copies of substantial portions of the Software may only be used in connection
 * with services provided by OneSignal.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#import <UIKit/UIKit.h>
@interface OneSignalCoreHelper : NSObject
#pragma clang diagnostic ignored "-Wstrict-prototypes"
#pragma clang diagnostic ignored "-Wnullability-completeness"

// Threading
+ (void)runOnMainThread:(void(^)())block;
+ (void)dispatch_async_on_main_queue:(void(^)())block;
+ (void)performSelector:(SEL)aSelector onMainThreadOnObject:(id)targetObj withObject:(id)anArgument afterDelay:(NSTimeInterval)delay;

+ (NSString*)trimURLSpacing:(NSString*)url;
+ (NSString*)parseNSErrorAsJsonString:(NSError*)error;
+ (BOOL)isOneSignalPayload:(NSDictionary *)payload;
+ (NSMutableDictionary*) formatApsPayloadIntoStandard:(NSDictionary*)remoteUserInfo identifier:(NSString*)identifier;
+ (BOOL)isRemoteSilentNotification:(NSDictionary*)msg;
+ (BOOL)isDisplayableNotification:(NSDictionary*)msg;
+ (NSString*)randomStringWithLength:(int)length;
+ (BOOL)verifyURL:(NSString *)urlString;
+ (BOOL)isWWWScheme:(NSURL*)url;

// For NSInvocations. Use this when wanting to performSelector with more than 2 arguments
+(void)callSelector:(SEL)selector onObject:(id)object withArgs:(NSArray*)args;
// For NSInvocations. Use this when wanting to performSelector with a boolean argument
+(void)callSelector:(SEL)selector onObject:(id)object withArg:(BOOL)arg;
/*
 A simplified enum for UIDeviceOrientation with just invalid, portrait, and landscape
 */
typedef NS_ENUM(NSInteger, ViewOrientation) {
    OrientationInvalid,
    OrientationPortrait,
    OrientationLandscape,
};

+ (ViewOrientation)validateOrientation:(UIDeviceOrientation)orientation;

+ (CGFloat)sizeToScale:(float)size;

+ (CGRect)getScreenBounds;

+ (float)getScreenScale;
@end
