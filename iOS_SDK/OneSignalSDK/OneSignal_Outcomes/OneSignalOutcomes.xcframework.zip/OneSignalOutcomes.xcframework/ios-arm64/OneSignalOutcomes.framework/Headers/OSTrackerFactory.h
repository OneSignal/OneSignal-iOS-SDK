/**
Modified MIT License

Copyright 2020 OneSignal

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

1. The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

2. All copies of substantial portions of the Software may only be used in connection
with services provided by OneSignal.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

#import "OSInfluenceDataRepository.h"
#import "OSInfluence.h"
#import "OSChannelTracker.h"
#import <OneSignalCore/OneSignalCore.h>


@interface OSTrackerFactory : NSObject

+ (OSTrackerFactory* _Nonnull)sharedTrackerFactory;

- (id _Nonnull)initWithRepository:(OSInfluenceDataRepository * _Nonnull)dataRepository;
- (void)saveInfluenceParams:(NSDictionary * _Nonnull)params;
- (void)initFromCache;
- (NSArray<OSInfluence *> * _Nonnull)influences;
- (NSArray<OSInfluence *> * _Nonnull)sessionInfluences;
- (OSChannelTracker * _Nonnull)iamChannelTracker;
- (OSChannelTracker * _Nonnull)notificationChannelTracker;
- (OSChannelTracker * _Nullable)channelByEntryAction:(AppEntryAction)entryAction;
- (NSArray<OSChannelTracker *> * _Nonnull)channels;
- (NSArray<OSChannelTracker *> * _Nonnull)channelsToResetByEntryAction:(AppEntryAction)entryAction;

@end
